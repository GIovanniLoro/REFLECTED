﻿namespace Server;

public class ManageNetwork
{
    
}