﻿namespace ScreenServer;

public class ImageUtils
{
    
}