# REFLECTED
Development of a screen mirroring software based on client server architecture
